package com.example.hospitalcenter;

public class DBconfig {
    //data hospital
    public static final String SERVER_GET_URLH = "http://apihospital.zainportfolio.com/api/hospital/get_hospital";

    //data pasien
    public static final String SERVER_GET_URLP = "http://apihospital.zainportfolio.com/api/pasien/get_pasien";

    //data lengkap hospital
    public static final String SERVER_GET_URLJ = "http://apihospital.zainportfolio.com/api/lokasi/joinhospital";
}
